%% GPU CUDA
% This example shows how to use CUDA code within MATLAB to run against a gpuArray.

%% Load Data
% Load stored image data
load('imageData.mat')

%% Run Both
% Run the data through the two implementations
adjustedImageCPU = whitebalance(imageData);
adjustedImageGPU = whitebalance_cuda(imageData);

%% Compare Outputs
% Visualize the results and their difference
subplot(1,2,1)
imshow(adjustedImageCPU)
title('MATLAB Implementation')
subplot(1,2,2)
imshow(adjustedImageGPU)
title('CUDA Implementation')

difference = abs(double(adjustedImageCPU(:)) - double(adjustedImageGPU(:)));
msgbox(['The maximum difference is: ' num2str(max(difference))]);

%% Compare Speed
% Evaluate and time whitebalance algorithms

tCPU = timeit(@()whitebalance(imageData))
tCUDA = gputimeit(@()whitebalance_cuda(imageData))
