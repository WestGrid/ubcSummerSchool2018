function parfor_structcell_solution

z.data = rand(4,4);
z.unusedata = magic(100);
means = zeros(1,4);
c = num2cell(z.data,1); % Convert to cell columnwise
parfor ii = 1:4
    % Index into cell with loop variable
    means(ii) = mean(c{ii}); 
end
disp(means)
