%% Identify the issue with the following code - implement a workaround
function t = parfor_nested()

rng default
n = 5;
t = zeros(n);

parfor idx = 1:n
   parfor jdx = 1:n
      t(jdx,idx) = max(rand(1,jdx));
   end
end
