%% Workaround: wrap inner parfor in a function
function t = parfor_nested_solution()

    rng default
    n = 5;
    t = zeros(n);

    parfor idx = 1:n
       t(:,idx) = localFcn(n);
    end
    
end

function t = localFcn(n)
    t = zeros(n,1);
    % When called inside of a parfor-loop.  This will run as a for-loop.
    parfor jdx = 1:n
       t(jdx) = max(rand(1,jdx));
    end
end
