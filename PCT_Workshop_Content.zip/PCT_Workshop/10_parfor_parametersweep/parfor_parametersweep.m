%% Truss Deflection - Parameter Sweep
% This is a parameter sweep study of the effect of the number of elements
% and element cross sectional area on the displacement at the tip of a
% cantilevered truss.
%
% Copyright 2016 The MathWorks, Inc.
%

%% Initialize Problem

% Number of elements and cross sectional area of each element
nNum = 8; 
aNum = 8;

% Vectors of number of elements and cross section areas to sweep
nVals = (1:nNum)+10; % number of segments, start with 11
aVals = linspace(100, 200, aNum); % cross sectional area    
peakVals = nan(nNum,aNum); % peak value results matrix


%% Parameter Sweep
%
% Write a parfor-loop to loop over every combination of nVals and aVals
% calling trussCantilever storing the peak deflection at the tip.
% trussCantilever is called with:
%
%    y = trussCantilever(n,a)
%    ypeak = max(y(:,end))    
%
% Store the matrix of peak values in peakVals.
%
% There are two ways of doing this, one with nested loops, the other with a
% grid of parameter combinations.  For more information on the latter, see
% >>doc meshgrid
%
% Time this with a for-loop and a parfor-loop

%% First way
t0 = tic;

toc(t0)



%% Second way

% Grid of all combinations
[nGrid, aGrid] = meshgrid(nVals, aVals);

t0 = tic;


toc(t0)



%% Visualize results
% Show the parameter sweep grid results

visualizeParamSweep(nVals, aVals, peakVals);

