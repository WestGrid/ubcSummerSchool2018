%% Batch Intro
%

doc batch

% Batch jobs require their own pool.  Delete any existing ones.
delete(gcp('nocreate'))

%% Offload serial computation
% Use batch command to offload serial computation to one worker
% Use the 50 and 10000 as the inputs to ex_serial.
%
% Call it job1

job1 = batch('ex_serial',1,{50,10000});


%% Open the Parallel Job Monitor
%
% Home Tab -> Parallel -> Job Monitor
%
% Look at the state of your job


%% Get the results from job1 back to client (interactively)


%% Offload parallel computation
% Use the batch command to offload ex_parallel to a pool of workers.
% Use the 50 and 10000 as the inputs to ex_parallel.
%
% Hint: The pool size should be one less than the number of workers in the
% pool.  Why?
%
% Call it job2

N = 2; % number of workers
job2 = batch('ex_parallel',1,{50,10000},'Pool',N-1);


%% Query the state of job2 programatically

job2.State


%% Wait for job2 to finish

wait(job2)


%% Get results back to client (programatically)

results2 = fetchOutputs(job2);


%% Clean up
% Clean up job1 interactively from the job monitor
% Clean up job2 programatically

delete(job2)

