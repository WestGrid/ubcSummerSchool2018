%% Hint

doc labindex

%% 
x = (0:0.01:6).';

spmd
    switch labindex
        %% Compute the sine of x on lab 1
        case 1
            y = sin(x);
            
        %% Compute the cosine of x on lab 2
        case 2
            y = cos(x);
    end
end

%% Display results at the command line

disp(y)


%% Plot results

plot(x, [y{1} y{2}])

