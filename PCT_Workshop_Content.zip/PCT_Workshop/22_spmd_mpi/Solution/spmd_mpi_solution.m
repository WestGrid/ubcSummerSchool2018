%% Hints

doc labSend
doc labReceive
doc numlabs

%% Generate different data on each worker

spmd
    %% N-by-N matrix filled with Ns (N = labindex)
    dataToSend = labindex+zeros(labindex);
    
    %% Send data from lab 1 to lab 2 and so on
    if labindex < numlabs % all workers but last 
        labSend(dataToSend, labindex+1);
    else
        % Last worker sends to first
        labSend(dataToSend, 1) 
    end
        
    %% Receiving data on each worker
    if labindex > 1 % all workers but first
        dataReceived = labReceive(labindex-1);
    else 
        % first worker receives from last
        dataReceived = labReceive(numlabs); 
    end 
    
    %% Display received data on each worker
    disp(dataReceived)
end

%% Fetch data back to client
dataOnClient = dataReceived(:);