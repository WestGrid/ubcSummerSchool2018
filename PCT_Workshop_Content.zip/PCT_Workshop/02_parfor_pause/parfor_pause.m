%% How much time will the following for-loop take?
tic
for k=1:18
    pause(1)
end
toc

%% Open parallel pool
p=gcp;

%% How much time will the following parfor-loop take?
tic
parfor k=1:18
    pause(1)
end
toc