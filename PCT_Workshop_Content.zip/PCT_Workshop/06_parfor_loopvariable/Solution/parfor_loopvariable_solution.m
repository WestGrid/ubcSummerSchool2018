%% Parfor Loop Variable
% Take the following for-loop and turn it into a parfor-loop.
% What happens, does it run?
% Implement a workaround.

z = 0;
xAll = 0:0.1:1; % create a vector with the values we want to loop over
parfor ii = 1:length(xAll) % loop with increasing integers
    x = xAll(ii); % index into original vector with index
    z = z + x;
end