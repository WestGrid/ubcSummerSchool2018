% This is an example of a "Needle in the haystack" type problem.  I.e. we
% want to run something until we get an answer that meets our criteria.  It
% could be an optimization problem converging, a design meeting our
% requirements, or all tests passing.

%% Initialize Problem

% Number of elements and cross sectional area of each element
nNum = 20;
aNum = 20;

% Vectors of number of elements and cross section areas to sweep
nVals = (1:nNum)+10; % number of segments, start with 11
aVals = linspace(100, 200, aNum);  % cross sectional area

% Grid of all combinations
[nGrid, aGrid] = meshgrid(nVals, aVals);

% Peak value results matrix
peakVals = nan(nNum,aNum);


%% Parameter Sweep
% Try to turn this into a parfor-loop.
t0 = tic;
for ii = 1:numel(aGrid)
    % Fill futures with parallel tasks
    Y = trussCantilever(nGrid(ii),aGrid(ii)); 

    % Determine peak deflection in Y direction at the tip
    peakVals(ii) = max(Y(:,end));
    
    % Test to see if we can be done, 85% of peak and half way through
    if (peakVals(ii) < 0.017)
        break
    end
end
toc(t0)


%% Visualize results
% Show the parameter sweep grid results

visualizeParamSweep(nVals, aVals, peakVals);
