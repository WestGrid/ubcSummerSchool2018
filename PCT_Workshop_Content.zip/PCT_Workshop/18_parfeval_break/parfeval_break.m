%% Initialize Problem

% Number of elements and cross sectional area of each element
nNum = 20;
aNum = 20;

% Vectors of number of elements and cross section areas to sweep
nVals = (1:nNum)+10; % number of segments, start with 11
aVals = linspace(100, 200, aNum);  % cross sectional area

% Grid of all combinations
[nGrid, aGrid] = meshgrid(nVals, aVals);

% Peak value results matrix
peakVals = nan(nNum,aNum);


%% Parameter Sweep
%
t0 = tic;
for ii = 1:numel(aGrid)
    % Fill futures with parallel tasks in FIFO order
    iterations(ii) = parfeval(@trussCantilever,1,nGrid(ii),aGrid(ii));         %#ok<SAGROW>
end
disp('Futures all queued');
for ii = 1:numel(aGrid)
    % fetchNext blocks until next results are available.
    [idx,Y] = fetchNext(iterations);    
    peakVals(idx) = max(Y(:,end));
    
    % Test to see if we can be done, 85% of peak and half way through
    if (peakVals(idx) < 0.017) % 0.85*nanmax(peakVals(:))) && (idx > numel(aGrid)/2)
        cancel(iterations);
        break
    end
end
toc(t0)


%% Visualize results
% Show the parameter sweep grid results

visualizeParamSweep(nVals, aVals, peakVals);
