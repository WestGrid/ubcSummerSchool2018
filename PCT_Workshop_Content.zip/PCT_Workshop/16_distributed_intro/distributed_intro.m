%% An introduction to creating and using distributed arrays
% The example below creates a distributed array (different parts of the
% array are located on different workers) and manipulates it straight
% from the client MATLAB. Distributed arrays also have overloaded plotting
% methods which can be used to easily downsample or subsample large data.

%% Instructions for participants
% No changes necessary. Run using a parallel pool.

%% Creating an array

a = rand(1000,1000);

%% Distribute a to the workers
% Hint: doc distributed


%% What can you do with a?
% Hint: doc methods


%% Creating a distributed array
% Create two random distributed arrays:
% * D, which is 1000x1000
% * D2 which is 100x100
%
% Create these arrays so that the data never lived on the client.


%% Checking the sizes and classes
% Both D and D2 are the same size in the client workspace, since data is
% held on the workers.

whos


%% Doing math on distributed arrays
% Create another array, B, like D, i.e. a distributed array 1000x1000



%% Multiply
% Mutliple B*D and store it in M.


%% Plotting distributed arrays
% The "plot" command is overloaded to work with distributed arrays.
% This brings data back to the client.  Plot every 100th element of M in
% both dimensions


%% Gathering the data to a client-side double array
% Gather all of M back into the client, store it in Mgather
% Hint: doc gather

% Note that Mgather is much larger than M in the client workspace.
whos

