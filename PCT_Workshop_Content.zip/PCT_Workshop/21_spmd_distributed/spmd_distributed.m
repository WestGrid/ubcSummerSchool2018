%% Simple SPMD Example
% This example illustrates our spmd capabilites. 
% Just run through the example

%% serial part of code

n = 100;


%% simple spmd block

spmd
    a = rand(n,n);
    disp(size(a))
    disp(a(1:2,1:2))
end

%% spmd with distributed arrays (creating)

spmd
    a = rand(n,n,codistributor); % uses default distribution
    disp(size(getLocalPart(a))); 
end

%% spmd with distributed arrays (duplicated)

spmd
    b = ones(n,n); 
    a = codistributed(b); % uses default distribution
    disp(size(b));
    disp(size(a)); 
    disp(size(getLocalPart(a)));
end

%% spmd with distributed arrays (variant)

spmd
    d = rand(n,n); 
    codist = codistributor1d(0,[],[n, numlabs*n]); % uses default distribution
    e = codistributed.build(d,codist);
    disp(size(d));
    disp(size(e)); 
end

%% Data stays on workers between spmd blocks

spmd
    d = svd(a);
    disp(max(d))
end

