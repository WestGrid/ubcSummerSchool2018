%% Hint: 

doc parpool


%% Open and close a parallel pool interactively
% Hint: look at bottom left corner of MATLAB desktop


%% Open pool of 2 local MATLAB workers


%% Query size of pool of workers
% Hint:  How do you handle the case of no pool being open?
%


%% Close pool of workers



