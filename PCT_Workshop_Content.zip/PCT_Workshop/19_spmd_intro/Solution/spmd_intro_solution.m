%% Hint

doc spmd

%% Create a 10x10 matrix with random numbers on each worker

n = 10;

spmd
    a = rand(n,n);
    
    % Display the size of the created array on each worker
    disp(size(a))
    
    % Display the (1:2,1:2) values on each worker
    disp(a(1:2,1:2))
end

%% Access array of second worker from client
aClient = a{2};
aClient(1:2,1:2)


%% Compute singular values of array on each worker
% 
% Hint: Use |svd| to calculate the singular values
%

spmd
    d = svd(a);
    
    % Display the maximum singular value on each worker
    disp(max(d))
end

