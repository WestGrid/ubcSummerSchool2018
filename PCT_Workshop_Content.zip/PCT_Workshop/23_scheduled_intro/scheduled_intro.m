%% Hints

doc parcluster
doc createJob
doc createTask


%% Find Parallel Computing Resource


%% Create Job


%% Attach a task to the job
% Use @rand for the task


%% Submit Job


%% Check the job's properties


%% Check the job's state


%% Wait until job is done


%% Check for Errors


%% Get results


%% Destroy job

