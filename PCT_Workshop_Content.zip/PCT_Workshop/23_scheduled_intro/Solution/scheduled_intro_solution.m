%% Hints

doc parcluster
doc createJob
doc createTask


%% Find Parallel Computing Resource

c = parcluster;


%% Create Job

job = createJob(c);


%% Attach a task to the job

task = createTask(job,@rand,1,{});


%% Submit Job

submit(job)


%% Check the job's properties

job


%% Check the job's state

job.State


%% Wait until job is done

wait(job,'finished')


%% Check for Errors

if ~isempty(task.ErrorMessage)
   error(task.ErrorMessage)
end


%% Get results

y = getAllOutputArguments(job);
s = y{1}.^2;
display(s)


%% Destroy job

destroy(job)

