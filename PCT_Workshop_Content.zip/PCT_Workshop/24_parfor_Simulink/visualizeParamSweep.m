function visualizeParamSweep(bVals, kVals, peakVals)
% visualizeParamSweep(bVals, kVals, peakVals);
% Plotter for ODE parameter sweep examples
%
% Copyright 2009-2016 The MathWorks, Inc.

ax = gca;
surf(ax,bVals, kVals, peakVals)
xlabel(ax,'Damping (b)')
ylabel(ax,'Stiffness (k)')
zlabel(ax,'Peak Response')
title('Peak Values for Solutions to $m\ddot{x} + b\dot{x} + kx = 0$', ...
      'Interpreter', 'latex', 'FontSize', 16, 'FontWeight', 'Bold')
view(ax,50, 30)

end

