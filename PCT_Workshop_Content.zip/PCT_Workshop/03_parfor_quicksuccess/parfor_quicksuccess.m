%% Run serial example
% Time running ex_serial() with inputs 50 and 10000.  
%  
%   r = ex_serial(50,10000);

tic
rserial = ex_serial(50,10000);
tserial = toc


%% Run parallel example
% Modify ex_parallel to use a parfor loop.
% Time it with the same inputs, 50, 10000
%
% Hint: make sure parallel pool is open before timing
% 
tic
rparallel = ex_parallel(50,10000);
tparallel = toc


%% Compare processing time
disp(['Serial processing time: ' num2str(tserial)])
disp(['Parallel processing time: ' num2str(tparallel)])

% Comparing results
histogram(rserial, 23:0.2:27)
hold on
histogram(rparallel, 23:0.2:27)
xlim([23 27])
title('Results Serial v. Parallel')
legend show