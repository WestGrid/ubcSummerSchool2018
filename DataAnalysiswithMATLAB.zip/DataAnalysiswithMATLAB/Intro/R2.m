function R_Sqr = R2(Y, YHat )
%RSQUARED

SStot = sum((Y - mean(Y)).*(Y - mean(Y)));

% Calculate residuals
resid = Y - YHat;

% Square residuals
resid_sqrd = resid.*resid;

% Take the sum of the squared residuals
SSerr = sum(resid_sqrd);

% Calculate R^2
R_Sqr = 1 - (SSerr/SStot);

end

