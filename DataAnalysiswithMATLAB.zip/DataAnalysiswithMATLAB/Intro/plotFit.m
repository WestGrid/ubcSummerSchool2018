function  plotFit(y,varargin)
% Plot fit
% Copyright 2015 The MathWorks, Inc.

figure
legendName = cell(length(varargin),1);
hold on

for ii = 1:length(varargin)
    yfit = varargin{ii};
    plot(yfit, (y- yfit)./yfit,'o')
    rs = R2(y,yfit);
    legendName{ii,1} = sprintf('%s (R^2=%0.3f)', inputname(ii+1), rs);
end

ylim([-1.5 1.5])
legend(legendName)

hold off

legend(legendName)

refline(0,0)
xlabel('Estimated Fuel Economy (MPG)')
ylabel('Error/Estimated Fuel Economy')

figure;
hold all
axis square

linesymbols = {'+','o','*','x'};

for ii = 1:length(varargin)
    counter = 1 + mod((ii-1),4);
    yfit = varargin{ii};
    plot(y, yfit,linesymbols{counter})
end
hold off

line([0 max(y)] ,[0 max(y)],'Color','k')

xlabel('Actual Fuel Economy (MPG)')
ylabel('Estimated Fuel Economy (MPG)')

legend(legendName)

