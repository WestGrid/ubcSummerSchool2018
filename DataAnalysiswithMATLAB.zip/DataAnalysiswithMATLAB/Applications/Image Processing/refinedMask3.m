function [resultimg,pctInfection] = refinedMask3(inputImg)

% Preprocess images to minimize variability
targetImage = imread('BabesiosisRGB.jpg');
img = imhistmatch(inputImg,targetImage);

% Detect cell circles
detectCellCircles = @(x) imfindcircles(x,[20 35], ...
   	'Sensitivity',0.89, ...
   	'EdgeThreshold',0.04, ...
   	'Method','TwoStage', ...
   	'ObjectPolarity','Dark');
[centers, radii] = detectCellCircles(img);

% Initialize variables for infection and cell masks
infectionMask = false(size(img(:,:,1)));
cellMask = false(size(img(:,:,1)));

% Loop through all the detected circles and determine the presence of infection
isInfected = false(numel(radii),1);
x = 1:size(img,2);
y = 1:size(img,1);
[xx,yy] = meshgrid(x,y);

infectionThreshold = 135;
grayCellImage = rgb2gray(img);

for ii = 1:numel(radii)
    currentCellImage = grayCellImage;
	mask = hypot(xx - centers(ii,1), yy - centers(ii,2)) <= radii(ii);
	currentCellImage(~mask) = 0;
	infection = currentCellImage > 0 & currentCellImage < infectionThreshold;
    infection = bwareafilt(infection,[5 inf]);

	isInfected(ii) = any(infection(:));
	infectionMask = infectionMask|infection;
    cellMask = cellMask|boundarymask(mask);
end
pctInfection = sum(isInfected)/numel(radii);

% Prepare output image
resultimg = inputImg;
r = resultimg(:,:,1);
g = resultimg(:,:,2);
b = resultimg(:,:,3);

r(infectionMask) = 255;
g(infectionMask) = 0;
b(infectionMask) = 0;

r(cellMask) = 0;
g(cellMask) = 0;
b(cellMask) = 255;

resultimg(:,:,1) = r;
resultimg(:,:,2) = g;
resultimg(:,:,3) = b;