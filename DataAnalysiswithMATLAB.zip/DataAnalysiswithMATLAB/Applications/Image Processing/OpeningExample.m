%% Automated detection and quantification of Babesiosis infection
% Babesiosis is a malaria-like, tick-borne parasitic disease common in
% parts of the US, and present sporadically throughout the rest of the
% world. Our goal here is to EXPLORE options for developing an automated
% function to DETECT the presence of the Babesia parasite in thin blood
% smears, and to QUANTIFY the portion of RBCs in a sample that are
% infected.
%
% Brett Shoelson,PhD; Avi Nehemiah
% Modified jpingel Oct-2015 

%% OUR FOCUS
%
% Exploration
% UI usage
% Segmentation
% Pre-processing

%% Babesiosis Images
babesiosisDir = fullfile(pwd '..\BloodSmearImages\babesiosis');

% Convenient referencing of a collection of images? 
imgSet = imageSet(babesiosisDir); %#ok<*NOPTS>

%% To develop an algorithm, let's select a "Target Image"
targetImgNum = 4;
targetImage = read(imgSet,targetImgNum);
infectionThreshold = 135;
detectCircles = @(x) imfindcircles(x,[20 35], ...
	'Sensitivity',0.89, ...
	'EdgeThreshold',0.04, ...
	'Method','TwoStage', ...
	'ObjectPolarity','Dark');

%% Is this more generalizable?
ax = displayRawImages(imgSet);
%
for ii = 1:imgSet.Count
	[pctInfection,centers,radii,isInfected,infectionMask] = ...
		testForInfection(getimage(ax(ii)),targetImage,...
		infectionThreshold,detectCircles);
	title(ax(ii),...
		['Pct Infection: ', num2str(pctInfection,2),...
		' (' num2str(sum(isInfected)),...
		' of ' num2str(numel(isInfected)) ')']);
	viscircles(ax(ii),centers,radii,'edgecolor','b');
	% createCirclesMask
	infectedCellsMask = createCirclesMask(targetImage,...
		centers(isInfected,:),...
		radii(isInfected));
	showMaskAsOverlay(0.3,infectedCellsMask,'g',ax(ii),false);
	showMaskAsOverlay(0.5,infectionMask,'r',ax(ii),false);
	drawnow
end
expandAxes(ax);

%% Now generate a report
% options = {'html','doc','latex','ppt','xml','pdf'};
% myDoc = publish('ParasitologyDemo.m',options{6})
% winopen(myDoc)

