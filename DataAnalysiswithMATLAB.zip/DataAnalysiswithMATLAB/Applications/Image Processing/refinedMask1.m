takfunction cellMask = refinedMask1(testImage)
% cellMask = refinedMask(testImage)

cellMask = createCellMask(testImage);
cellMask = filterCellRegions(cellMask);

SE  = strel('Disk',10,4);
morphed = imsubtract(imadd(testImage,imtophat(testImage,SE)),imbothat(testImage,SE));
SE  = strel('Disk',2,4);
morphed = imsubtract(imdilate(morphed, SE),imerode(morphed, SE));
morphed = rgb2gray(morphed);
morphed = morphed > 45;

morphed = bwareaopen(morphed,500,4);
morphed = bwmorph(morphed, 'skeleton', Inf);
edges = bwmorph(morphed, 'spur', Inf);

edges = imdilate(edges,strel('Disk',1));
cellMask = cellMask & ~edges;

end