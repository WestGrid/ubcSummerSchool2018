function actnames = getActivityNames()

actnames = {'Walking'  'WalkingUpstairs'  'WalkingDownstairs'  'Sitting'...
    'Standing'  'Laying'};


