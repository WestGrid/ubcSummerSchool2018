To run this example, please go through the following steps

1. Set MATLAB Current Folder to the folder containing this read_me.txt file

2. Download and pre-process the data set automatically following the steps
   in the script DataPreparation.mlx (only necessary the first time)

3. Open the script SensorDataAnalytics.m and execute the code one cell at a time
   using the MATLAB editor.
